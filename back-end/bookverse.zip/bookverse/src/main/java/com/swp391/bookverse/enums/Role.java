package com.swp391.bookverse.enums;

public enum Role {
    ADMIN,
    USER
    ;
}
