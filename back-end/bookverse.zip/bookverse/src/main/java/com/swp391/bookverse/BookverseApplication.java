package com.swp391.bookverse;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookverseApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookverseApplication.class, args);
	}

}
