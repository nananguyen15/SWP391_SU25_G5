package com.swp391.bookverse.repository;

import com.swp391.bookverse.entity.Promotion;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PromotionRepository extends JpaRepository<Promotion, Long> {
}